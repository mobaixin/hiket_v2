package cn.hope.hiket.utils.nku.Throw;

import java.io.Serializable;

public class Success extends Exception implements Serializable {
	private static final long serialVersionUID = 5981948310484911915L;
	public Success() {
		super();
	}
}
