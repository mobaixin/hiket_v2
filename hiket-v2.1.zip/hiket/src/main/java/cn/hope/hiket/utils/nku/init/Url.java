package cn.hope.hiket.utils.nku.init;

public class Url {
	public static String HOME_URL = "http://eamis.nankai.edu.cn";
	public static String LOGIN_URL = HOME_URL + "/eams/login.action";
	public static String GRADE_URL = HOME_URL + "/eams/myPlanCompl.action";
	public static String GRADUATE_LOGIN_URL ="http://urp.nankai.edu.cn/userPasswordValidate1.portal";
}
