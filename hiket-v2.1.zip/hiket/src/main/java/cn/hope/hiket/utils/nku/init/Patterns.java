package cn.hope.hiket.utils.nku.init;

public class Patterns {
	public static String student_id = "<td class=\"content\" width=\"18%\">([0-9]{7})</td>";
}
