package cn.hope.hiket.utils.nku.Throw;

import java.io.Serializable;

public class PasswordError extends Exception implements Serializable {
	private static final long serialVersionUID = -3032189197995944041L;

	public PasswordError() {
		super();
	}
}
