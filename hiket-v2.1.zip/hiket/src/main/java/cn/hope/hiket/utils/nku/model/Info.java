package cn.hope.hiket.utils.nku.model;

import lombok.Data;

@Data
public class Info {
	private String number;
	private String name;
	private String faculty;
	private String year;
}
