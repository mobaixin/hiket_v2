package cn.hope.hiket.utils.nku.model;

import lombok.Data;

@Data
public class Student {
	private String number;
	private String password;
	private Info info;
}















